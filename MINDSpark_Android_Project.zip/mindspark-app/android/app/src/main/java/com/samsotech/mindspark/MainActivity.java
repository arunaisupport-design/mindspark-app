package com.samsotech.mindspark;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
