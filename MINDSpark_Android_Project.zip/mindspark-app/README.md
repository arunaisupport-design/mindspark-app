# MINDSpark – Android app

Engineer wellbeing and development app for Samsotech (MVP prototype).
Built with Capacitor 8: the app is the web app in `www/` running inside a native Android shell.

- App ID: `com.samsotech.mindspark`
- App name: MINDSpark
- Android 7.0+ (minSdk 24, targetSdk 36)
- Works fully offline (fonts and Excel reader bundled). No server needed yet.
- Progress (name, XP, badges, workout ticks, question approvals) is saved on the phone only.
  Fitness calculator inputs are never saved.

## Option A – Build the APK on GitHub (no Android Studio needed)

1. Create a private GitHub repository and push this folder to `main`.
2. GitHub runs **Actions → Build MINDSpark Android APK** automatically
   (or run it manually from the Actions tab with *Run workflow*).
3. When it finishes (~5 min), open the run and download **MINDSpark-debug-apk**.
4. Unzip it, copy `app-debug.apk` to the phone and open it
   (allow "Install unknown apps" for your file manager or browser once).

## Option B – Build on a PC with Android Studio

Needs: Node.js 22+, Android Studio (latest), JDK 21 (bundled with Android Studio).

```bash
npm install
npx cap sync android
npx cap open android        # opens the project in Android Studio
```

In Android Studio: wait for Gradle sync, then
**Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
The file is at `android/app/build/outputs/apk/debug/app-debug.apk`.
To test on a phone, enable USB debugging and press **Run ▶**.

## Releasing to staff (Intune / Play Store)

The debug APK is fine for testing. For distribution:

1. Android Studio → **Build → Generate Signed Bundle / APK** → create a keystore
   (keep it and its passwords safe – every future update must use the same key).
2. Choose **APK** for Intune / sideloading, or **Android App Bundle (.aab)** for Google Play
   (private / managed Play is possible for internal-only apps).
3. Bump `versionCode` and `versionName` in `android/app/build.gradle` for every release.

## Changing the app

- Edit `www/index.html` (all screens, content and logic live there).
- Run `npx cap sync android` to copy changes into the Android project, then rebuild.
- Icons and splash screen are in `android/app/src/main/res/` (mipmap-* and drawable-*).

## What is in this version

Home dashboard · Samsotech Arena (Quick Fire quizzes, 4 troubleshooting scenarios) ·
Hotel 360 (virtual five-star hotel, 17 departments, guest journey, KPIs, glossary, quiz) ·
Fitness (6-day workout plan tracker, BMI, calories, water, heart-rate zones, desk stretch) ·
Brain Gym (4 games) · Breaks (breathing, focus reset, reaction game) ·
Leaderboard (sample data) · Admin (question approval, Excel import, audit log).

Android back button closes open screens, then returns Home, then exits.

## Not included yet (next phase)

Company Microsoft sign-in, central database and real leaderboards, push notifications,
AI Coach, iOS build (needs a Mac and Apple Developer account).
Sample questions and leaderboard names must be replaced or validated before go-live.
